# Acordes del Barrio — Backend (API REST)

Entrega 3 · Backend · Dispositivos Móviles 2-2026 · Ferney Arturo Diaz Cerquera

API REST para consultar disponibilidad y reservar salas de ensayo e instrumentos, evitando reservas superpuestas.

**Stack:** Node.js 22.13+ (o 24) · Express 5 · MongoDB (driver oficial `mongodb`). Configura la conexión en `.env` (ver `../MONGODB.md`); las colecciones e índices se crean solos al iniciar.

## Puesta en marcha
```bash
npm install
npm start          # http://localhost:3000
npm test           # 13 pruebas automáticas
```
Para reiniciar los datos: borrar la base `acordes_del_barrio` en MongoDB Compass/Atlas y reiniciar el servidor.

## Base de datos (3 tablas, según la ficha)
- `usuario (id_usuario PK, nombre, rol, correo UNIQUE)`
- `recurso (id_recurso PK, nombre, tipo, estado_disp, ubicacion)`
- `reserva (id_reserva PK, id_usuario FK, id_recurso FK, fecha, hora_inicio, hora_fin, estado)`

Datos semilla: usuario 1 = encargado, 2 y 3 = estudiantes; 6 recursos (3 salas, 3 instrumentos; la Batería está en mantenimiento).

## Autenticación (simplificada)
Cada petición lleva la cabecera `X-User-Id: <id>` (1 encargado, 2 y 3 estudiantes). Solo `POST /api/users` y `/api/health` no la requieren.

## Endpoints
| Método | Endpoint | Descripción | Rol |
|---|---|---|---|
| GET | /api/health | Estado del servicio | — |
| POST | /api/users | Registrar estudiante `{nombre, correo}` | — |
| GET | /api/users | Listar usuarios | cualquiera |
| GET | /api/resources?tipo=&date= | Listar recursos (excluye inactivos) | cualquiera |
| GET | /api/resources/{id} | Detalle | cualquiera |
| GET | /api/resources/{id}/availability?date= | Franjas ocupadas del día | cualquiera |
| POST | /api/resources | Crear recurso | encargado |
| PUT | /api/resources/{id} | Editar recurso | encargado |
| DELETE | /api/resources/{id} | Desactivar (borrado lógico) | encargado |
| GET | /api/reservations?resourceId=&date= | Reservas por recurso y fecha | cualquiera |
| GET | /api/reservations?userId= | Reservas de un usuario | dueño / encargado |
| POST | /api/reservations | Crear reserva | cualquiera |
| PUT | /api/reservations/{id} | Editar reserva | dueño / encargado |
| PATCH | /api/reservations/{id}/cancel | Cancelar reserva | dueño / encargado |

## Reglas de negocio
- **409 Conflict** si la nueva reserva se cruza con una reserva *activa* del mismo recurso y fecha. Franjas contiguas (10:00–11:00 tras 09:00–10:00) no son conflicto. Las canceladas liberan la franja.
- **400 Bad Request** si el recurso está en `mantenimiento` o `inactivo`.
- Otros códigos: 400 validación, 401 sin usuario, 403 sin permiso, 404 no existe.

## Ejemplo (caso de la pantalla 3 del boceto)
```bash
curl -X POST http://localhost:3000/api/reservations \
  -H "Content-Type: application/json" -H "X-User-Id: 2" \
  -d '{"id_recurso":1,"fecha":"2026-09-21","hora_inicio":"09:00","hora_fin":"10:00"}'
# repetir con X-User-Id: 3 y hora 09:30-11:00  ->  409
```

## Colección de pruebas
`postman/Acordes-del-Barrio.postman_collection.json` — importable en **Postman** e **Insomnia**.
32 requests con 46 aserciones. Ejecutar en orden (Collection Runner) con la API encendida y datos semilla.
Por consola: `npx newman run postman/Acordes-del-Barrio.postman_collection.json`

Evidencia de ejecución en `evidencia/`.
