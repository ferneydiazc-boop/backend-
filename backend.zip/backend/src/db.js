const { MongoClient } = require('mongodb');

const uri = process.env.MONGODB_URI || process.env.MONGO_URI || 'mongodb://127.0.0.1:27017';
const dbName = process.env.DB_NAME || 'acordes_del_barrio';
const client = new MongoClient(uri, { serverSelectionTimeoutMS: 8000 });
let db;

// Oculta el _id interno de Mongo: la API sigue usando id_usuario / id_recurso / id_reserva (numéricos)
const NO_ID = { projection: { _id: 0 } };
const col = (nombre) => db.collection(nombre);

async function conectar() {
  await client.connect();
  db = client.db(dbName);
  await col('usuario').createIndex({ id_usuario: 1 }, { unique: true });
  await col('usuario').createIndex({ correo: 1 }, { unique: true });
  await col('recurso').createIndex({ id_recurso: 1 }, { unique: true });
  await col('reserva').createIndex({ id_reserva: 1 }, { unique: true });
  await col('reserva').createIndex({ id_recurso: 1, fecha: 1 });
  await col('reserva').createIndex({ id_usuario: 1 });
  return db;
}
const getDb = () => db;
const cerrar = () => client.close();

// Autoincremental (1, 2, 3...) con una colección de contadores
async function siguienteId(nombre) {
  const r = await col('counters').findOneAndUpdate(
    { _id: nombre }, { $inc: { seq: 1 } }, { upsert: true, returnDocument: 'after' });
  const doc = r && r.value !== undefined ? r.value : r;   // compatible con distintas versiones del driver
  return doc.seq;
}

async function insertar(coleccion, campoId, datos) {
  const doc = { [campoId]: await siguienteId(coleccion), ...datos };
  await col(coleccion).insertOne(doc);
  delete doc._id;
  return doc;
}

// Exclusión mutua: evita que dos reservas simultáneas pasen la validación de solape a la vez
let cola = Promise.resolve();
function conBloqueo(fn) {
  const corrida = cola.then(fn);
  cola = corrida.catch(() => {});
  return corrida;
}

async function seed() {
  if ((await col('usuario').countDocuments()) > 0) return;
  await col('usuario').insertMany([
    { id_usuario: 1, nombre: 'Laura Encargada', rol: 'encargado', correo: 'encargado@acordes.local' },
    { id_usuario: 2, nombre: 'Carlos Estudiante', rol: 'estudiante', correo: 'carlos@acordes.local' },
    { id_usuario: 3, nombre: 'Ana Estudiante', rol: 'estudiante', correo: 'ana@acordes.local' },
  ]);
  await col('recurso').insertMany([
    { id_recurso: 1, nombre: 'Sala de ensayo 1', tipo: 'sala', estado_disp: 'disponible', ubicacion: 'Piso 1, sala A' },
    { id_recurso: 2, nombre: 'Sala de ensayo 2', tipo: 'sala', estado_disp: 'disponible', ubicacion: 'Piso 1, sala B' },
    { id_recurso: 3, nombre: 'Sala de ensayo 3', tipo: 'sala', estado_disp: 'disponible', ubicacion: 'Piso 2, sala C' },
    { id_recurso: 4, nombre: 'Guitarra eléctrica', tipo: 'instrumento', estado_disp: 'disponible', ubicacion: 'Armario 1' },
    { id_recurso: 5, nombre: 'Batería', tipo: 'instrumento', estado_disp: 'mantenimiento', ubicacion: 'Sala 2' },
    { id_recurso: 6, nombre: 'Teclado', tipo: 'instrumento', estado_disp: 'disponible', ubicacion: 'Armario 2' },
  ]);
  await col('counters').updateOne({ _id: 'usuario' }, { $set: { seq: 3 } }, { upsert: true });
  await col('counters').updateOne({ _id: 'recurso' }, { $set: { seq: 6 } }, { upsert: true });
}

module.exports = { conectar, cerrar, getDb, col, NO_ID, siguienteId, insertar, conBloqueo, seed };
