process.env.DB_NAME = 'acordes_test';   // base aparte: se borra en cada corrida
const test = require('node:test');
const assert = require('node:assert');
const { conectar, cerrar, getDb, seed } = require('../src/db');
const app = require('../src/app');

let base, server;
const ENC = 1, EST = 2, EST2 = 3;
const call = async (method, path, user, body) => {
  const res = await fetch(base + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(user ? { 'X-User-Id': String(user) } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, body: await res.json() };
};

test.before(async () => {
  await conectar();
  await getDb().dropDatabase();
  await conectar();   // recrea índices
  await seed();
  await new Promise((r) => { server = app.listen(0, r); });
  base = `http://localhost:${server.address().port}`;
});
test.after(async () => { server.close(); await getDb().dropDatabase(); await cerrar(); });

test('sin X-User-Id -> 401', async () => assert.strictEqual((await call('GET', '/api/resources')).status, 401));

test('listar recursos (sin inactivos) y filtrar por tipo', async () => {
  const r = await call('GET', '/api/resources?tipo=sala', EST);
  assert.strictEqual(r.status, 200);
  assert.ok(r.body.length === 3 && r.body.every((x) => x.tipo === 'sala'));
  assert.strictEqual((await call('GET', '/api/resources?tipo=xx', EST)).status, 400);
});

test('detalle de recurso 200 / 404', async () => {
  assert.strictEqual((await call('GET', '/api/resources/1', EST)).status, 200);
  assert.strictEqual((await call('GET', '/api/resources/999', EST)).status, 404);
});

test('CRUD de recursos: solo encargado', async () => {
  assert.strictEqual((await call('POST', '/api/resources', EST, { nombre: 'X', tipo: 'sala' })).status, 403);
  assert.strictEqual((await call('POST', '/api/resources', ENC, { nombre: 'X' })).status, 400);
  const c = await call('POST', '/api/resources', ENC, { nombre: 'Amplificador', tipo: 'instrumento' });
  assert.strictEqual(c.status, 201);
  const id = c.body.id_recurso;
  const u = await call('PUT', `/api/resources/${id}`, ENC, { ubicacion: 'Depósito' });
  assert.strictEqual(u.status, 200);
  assert.strictEqual(u.body.ubicacion, 'Depósito');
  const d = await call('DELETE', `/api/resources/${id}`, ENC);
  assert.strictEqual(d.body.estado_disp, 'inactivo');
});

let reservaId;
test('crear reserva válida -> 201', async () => {
  const r = await call('POST', '/api/reservations', EST, { id_recurso: 1, fecha: '2026-09-21', hora_inicio: '09:00', hora_fin: '10:00' });
  assert.strictEqual(r.status, 201);
  assert.strictEqual(r.body.estado, 'activa');
  assert.strictEqual(r.body.id_usuario, EST);
  reservaId = r.body.id_reserva;
});

test('REGLA PRINCIPAL: solape -> 409', async () => {
  const solapes = [['09:00', '11:00'], ['09:30', '09:45'], ['08:00', '09:30'], ['08:00', '12:00']];
  for (const [ini, fin] of solapes) {
    const r = await call('POST', '/api/reservations', EST2, { id_recurso: 1, fecha: '2026-09-21', hora_inicio: ini, hora_fin: fin });
    assert.strictEqual(r.status, 409, `${ini}-${fin} debía dar 409`);
  }
});

test('franjas contiguas, otra fecha u otro recurso NO son conflicto', async () => {
  for (const b of [
    { id_recurso: 1, fecha: '2026-09-21', hora_inicio: '10:00', hora_fin: '11:00' },
    { id_recurso: 1, fecha: '2026-09-21', hora_inicio: '08:00', hora_fin: '09:00' },
    { id_recurso: 1, fecha: '2026-09-22', hora_inicio: '09:00', hora_fin: '10:00' },
    { id_recurso: 2, fecha: '2026-09-21', hora_inicio: '09:00', hora_fin: '10:00' },
  ]) assert.strictEqual((await call('POST', '/api/reservations', EST2, b)).status, 201);
});

test('REGLA SECUNDARIA: recurso en mantenimiento/inactivo -> 400', async () => {
  const r = await call('POST', '/api/reservations', EST, { id_recurso: 5, fecha: '2026-09-21', hora_inicio: '09:00', hora_fin: '10:00' });
  assert.strictEqual(r.status, 400);
  assert.match(r.body.error, /no está disponible/);
});

test('validaciones -> 400 / 404', async () => {
  const ok = { id_recurso: 1, fecha: '2026-09-25', hora_inicio: '09:00', hora_fin: '10:00' };
  for (const bad of [
    { ...ok, hora_inicio: '11:00', hora_fin: '10:00' },
    { ...ok, fecha: '21/09/2026' },
    { ...ok, hora_inicio: '9am' },
    { ...ok, id_recurso: undefined },
  ]) assert.strictEqual((await call('POST', '/api/reservations', EST, bad)).status, 400);
  assert.strictEqual((await call('POST', '/api/reservations', EST, { ...ok, id_recurso: 999 })).status, 404);
});

test('consultar reservas por recurso+fecha y por usuario', async () => {
  const a = await call('GET', '/api/reservations?resourceId=1&date=2026-09-21', EST);
  assert.strictEqual(a.status, 200);
  assert.strictEqual(a.body.length, 3);
  const b = await call('GET', `/api/reservations?userId=${EST}`, EST);
  assert.ok(b.body.every((x) => x.id_usuario === EST));
  assert.strictEqual((await call('GET', `/api/reservations?userId=${EST2}`, EST)).status, 403);
});

test('disponibilidad del recurso', async () => {
  const r = await call('GET', '/api/resources/1/availability?date=2026-09-21', EST);
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.body.franjas_ocupadas.length, 3);
});

test('editar reserva: ok, solape 409, ajena 403', async () => {
  assert.strictEqual((await call('PUT', `/api/reservations/${reservaId}`, EST, { hora_fin: '09:45' })).status, 200);
  assert.strictEqual((await call('PUT', `/api/reservations/${reservaId}`, EST, { hora_fin: '10:30' })).status, 409);
  assert.strictEqual((await call('PUT', `/api/reservations/${reservaId}`, EST2, { hora_fin: '09:30' })).status, 403);
});

test('cancelar: ajena 403, propia 200, doble 400, libera franja', async () => {
  assert.strictEqual((await call('PATCH', `/api/reservations/${reservaId}/cancel`, EST2)).status, 403);
  const c = await call('PATCH', `/api/reservations/${reservaId}/cancel`, EST);
  assert.strictEqual(c.status, 200);
  assert.strictEqual(c.body.estado, 'cancelada');
  assert.strictEqual((await call('PATCH', `/api/reservations/${reservaId}/cancel`, EST)).status, 400);
  const re = await call('POST', '/api/reservations', EST2, { id_recurso: 1, fecha: '2026-09-21', hora_inicio: '09:00', hora_fin: '10:00' });
  assert.strictEqual(re.status, 201);
  assert.strictEqual((await call('PATCH', '/api/reservations/9999/cancel', EST)).status, 404);
});
